//
//  Array2Dimensional.swift
//  tetrisforassignment
//
//  Created by Alexander Lee on 15/10/19.
//  Copyright © 2019 Alexander Lee. All rights reserved.
//

// #1 ,#1 defines a class named Array2D. Normally arrays are made by struct but we need to use a class in this case as wherever we use the game board array in this project we will be manipulating the same data.
class Array2D<T> {
    let column: Int
    let row: Int
    // #2
    var array: Array<T?>
    
    init(column: Int, row: Int) {
        self.column = column
        self.row = row
        
        // #3
        array = Array<T?>(repeating: nil, count:row * column)
    }
    
    // #4
    subscript(columns: Int, rows: Int) -> T? {
        get {
            return array[(rows * column) + columns]
        }
        set(newValue) {
            array[(rows * column) + columns] = newValue
        }
    }
}
