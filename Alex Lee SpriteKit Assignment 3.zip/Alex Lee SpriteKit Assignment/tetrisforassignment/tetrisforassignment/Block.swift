//
//  Block.swift
//  tetrisforassignment
//
//  Created by Alexander Lee on 18/10/19.
//  Copyright © 2019 Alexander Lee. All rights reserved.
//

import SpriteKit

//#1
 let NumberOfColors: UInt32 = 6

//#2
 enum BlockColour: Int, CustomStringConvertible {

//#3
     case Blue = 0, Teal, Red, Yellow, Purple, Orange

//#4
     var spriteName: String {
         switch self {
         case .Blue:
             return "blue"
         case .Teal:
           return "teal"
         case .Red:
           return "red"
         case .Yellow:
             return "yellow"
         case .Purple:
           return "purple"
         case .Orange:
             return "orange"
         }
     }

//#5
     var description: String {
         return self.spriteName
     }

//#6
    static func random() -> BlockColour {
         return BlockColour(rawValue:Int(arc4random_uniform(NumberOfColors)))!
     }
 }

//#7
 class Block: Hashable, CustomStringConvertible {
//#8
     // Constants
     let colour: BlockColour

//#9
     // Properties
     var column: Int
     var row: Int
     var sprite: SKSpriteNode?

//#10
     var spriteName: String {
         return colour.spriteName
     }

//#11
     var hashValue: Int {
         return self.column ^ self.row
     }

//#12
     var description: String {
         return "\(colour): [\(column), \(row)]"
     }

     init(column:Int, row:Int, colour:BlockColour) {
         self.column = column
         self.row = row
         self.colour = colour
     }
 }

//#13
 func ==(lhs: Block, rhs: Block) -> Bool {
     return lhs.column == rhs.column && lhs.row == rhs.row && lhs.colour.rawValue == rhs.colour.rawValue
 }
